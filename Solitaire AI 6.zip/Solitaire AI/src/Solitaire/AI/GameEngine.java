package Solitaire.AI;

import java.util.ArrayList;

import Solitaire.AI.Pile.PileType;
public class GameEngine {

    ArrayList<Pile> tablePiles;
    ArrayList<Pile> foundationPiles;
    Pile deckPile, getPile;
    ArrayList<Pile> allPiles;
    ArrayList<String> buddy;
    ArrayList<Pile> deckPilesPlateRepresentation;
    ArrayList<Pile> deckOrderRepresentation;

    public final int pileNumber = 7;
    int talonCardvar;
    int talonCardCounter;
    int currentCardInGetPile;
    Boolean DEBUG = false;

    public Deck deck;

    public GameEngine() {
        generateCards();
    }

    public void generateCards() {

        deck = new Deck();
        deck.shuffle();

        deckPile = new Pile(120);
        deckPile.setOffset(0);

        getPile = new Pile(180);
        getPile.setOffset(0);

        foundationPiles = new ArrayList<Pile>();
        tablePiles = new ArrayList<Pile>();

        allPiles = new ArrayList<Pile>();
        allPiles.add(deckPile);
        allPiles.add(getPile);

        buddy = new ArrayList<String>();

        deckPilesPlateRepresentation = new ArrayList<Pile>();
        deckOrderRepresentation = new ArrayList<Pile>();

        talonCardvar = 0;
        talonCardCounter = 0;
        currentCardInGetPile = 0;

        /*for (int i = 0; i < deck.cards.size(); i++) {
            //System.out.println(deck.cards.get(i));

            Card card = deck.cards.get(i);
                if(card.cardSuit.name().equals("Spades")){
                    System.out.println(card.cardValue);
                }
        }*/

//        ArrayList<Card> Row1 = new ArrayList<Card>();
//        ArrayList<Card> Row2 = new ArrayList<Card>();
//        ArrayList<Card> Row3 = new ArrayList<Card>();
//        ArrayList<Card> Row4 = new ArrayList<Card>();
//        ArrayList<Card> Row5 = new ArrayList<Card>();
//        ArrayList<Card> Row6 = new ArrayList<Card>();
//        ArrayList<Card> Row7 = new ArrayList<Card>();
//
//        ArrayList<Card> Fund1 = new ArrayList<Card>();
//        ArrayList<Card> Fund2 = new ArrayList<Card>();
//        ArrayList<Card> Fund3 = new ArrayList<Card>();
//        ArrayList<Card> Fund4 = new ArrayList<Card>();
//
//        ArrayList<Card> DrawPile = new ArrayList<Card>();

        //if (Objects.equals(deck.cards.get(0), Card.valueInString(1))) {}

        /*
        addToRow(Row1, 1);
        addToRow(Row2, 2);
        addToRow(Row3, 3);
        addToRow(Row4, 4);
        addToRow(Row5, 5);
        addToRow(Row6, 6);
        addToRow(Row7, 7);
        */

//        printRow(Row1);
//        printRow(Row2);
//        printRow(Row3);
//        printRow(Row4);
//        printRow(Row5);
//        printRow(Row6);
//        printRow(Row7);

        //Change card
        //deck.cards.set(0, new Card(1, Card.CardSuit.Clubs));

        //System.out.println(deck.cards.get(0));
    }

    public void setupGame(){
        deckPile.pileType = PileType.Draw;
        getPile.pileType = PileType.Get;

        for (int i = 1; i <= pileNumber; ++i) {
            Pile pile = new Pile(120);
            for (int j = 1; j <= i; ++j) {
                Card card = deck.drawCard();
                pile.addCard(card);

                if (j != i) {
                    card.hide();
                } else {
                    card.show();
                }
            }

            tablePiles.add(pile);
            allPiles.add(pile);
        }

        for(int i = 0; i < 4; i++) {
                Pile pile = new Pile(100);
                pile.setOffset(0);
                pile.pileType = PileType.Final;
                foundationPiles.add(pile);
                allPiles.add(pile);
        }

        /*while (deck.cardSize() > 0) {
            Card card = deck.drawCard();
            card.hide();
            deckPile.addCard(card);
        }*/

        for (int i = 0; i < 6; i++) {
            Pile pile = new Pile(120);
            deckPilesPlateRepresentation.add(pile);
            if(DEBUG){
                System.out.println("Index: " + i);
            }
            for (int j = 0; j < 4; j++) {
                Card card = deck.drawCard();
                card.hide();
                deckPile.addCard(card);
                pile.addCard(card);

                if(DEBUG) {
                    System.out.println(deckPilesPlateRepresentation.get(i).cards.get(j));
                }
            }
        }

        correctIndexingOfDeckPlates();

        if(DEBUG) {
            System.out.println(buddy);
        }
        /*
        for(Pile piles : piles) {
            System.out.println(piles.cards.get(piles.cards.size()-1));
        }
        */

    }

    public void drawCards() {

        if (deckPile.isEmpty()) {
            while (!getPile.isEmpty()) {
                deckPile.addCard(getPile.cards.get(getPile.cards.size() - 1));
                getPile.removeCard(getPile.cards.get(getPile.cards.size() - 1));
                currentCardInGetPile = 0;
            }

            //Hide all cards in deck
            for (int j = 0; j < deckPile.cards.size(); j++) {
                deckPile.cards.get(j).hide();
            }
        }

        for (int i = 0; i < 3; i++) {
            if (!deckPile.isEmpty()) {
                Card drewCard = deckPile.drawCard();
                drewCard.isReversed = false;
                getPile.addCard(drewCard);
                if(i == 2) currentCardInGetPile++;
            } else {
                currentCardInGetPile++;
                break;
            }
        }
    }
                /*while(!getPile.isEmpty()){
                    drawPile.addCard(getPile.cards.get(getPile.cards.size() - 1));
                    getPile.removeCard(getPile.cards.get(getPile.cards.size() - 1));
                }

                //Hide all cards in deck
                for(int j = 0; j < drawPile.cards.size(); j++){
                    drawPile.cards.get(j).hide();
                }

                if(!drawPile.isEmpty()){
                    Card drewCard = drawPile.drawCard();
                    drewCard.isReversed = false;
                    getPile.addCard(drewCard);
                }*/

        /*if(drawPile.cards.size()-1 >= 3) {
            for (int i = 0; i < 3; i++) {
                    Card drewCard = drawPile.drawCard();
                    drewCard.isReversed = false;
                    getPile.addCard(drewCard);
            }
        } else {
            int count = drawPile.cards.size();
            int remainingDraw = 3 - count;
            //System.out.println("Size of drawpile is " + count);
            if(!drawPile.isEmpty()) {
                for (int i = 0; i < count; i++) {
                    Card drewCard = drawPile.drawCard();
                    drewCard.isReversed = false;
                    getPile.addCard(drewCard);
                }
            }

            while(!getPile.isEmpty()){
                drawPile.addCard(getPile.cards.get(0));
                getPile.removeCard(getPile.cards.get(0));
            }

            //Hide all cards in deck
            for(int i = 0; i < drawPile.cards.size(); i++){
                drawPile.cards.get(i).hide();
            }

            if(remainingDraw != 0 && !drawPile.isEmpty()) {
                for (int i = 0; i < remainingDraw; i++) {
                    if(!drawPile.isEmpty()) {
                        Card drewCard = drawPile.drawCard();
                        drewCard.isReversed = false;
                        getPile.addCard(drewCard);
                    }
                }
            }
        }

         */


    public boolean checkIfWin() {
        boolean flag=true;
        for (Pile pile : foundationPiles) {
            if (pile.cards.size() != 13) {
                return false;
            }
        }
        return true;
    }

    private void printRow(ArrayList<Card> arrayList){
        System.out.println("----------");
        for(Card card : arrayList){
            if(card == arrayList.get(arrayList.size()-1)) {
                System.out.println(card);
            } else {
                System.out.println("Unknown");
            }
        }
    }

    private void addToRow(ArrayList<Card> arrayList, int number){
        for(int i = 0; i < number; i++) {
            if(i != number-1){
                //deck.cards.set(i, new Card(0, Card.CardSuit.UnknownCard));
            }
            arrayList.add(i, deck.cards.get(i));
            deck.cards.remove(i);
        }
    }

    public void correctIndexingOfDeckPlates() {

        while (!buddy.isEmpty()) {
            buddy.remove(0);
        }

        for (int i = 0; i < 6; i++) {
            for (int k = 0; k < deckPilesPlateRepresentation.get(i).cards.size(); k++) {

                if (talonCardvar + 3 == talonCardCounter || (deckPilesPlateRepresentation.get(5).cards.size() - 1 == k && i == 5)) {
                    talonCardvar = talonCardCounter;

                    buddy.add(i + "," + k);
                }
                talonCardCounter++;
            }
        }
        talonCardvar = 0;
        talonCardCounter = 0;
    }
}
