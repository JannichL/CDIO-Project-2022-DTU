package Solitaire.AI;

import java.io.IOException;
import java.io.*;
import java.util.*;
import com.fazecast.jSerialComm.SerialPort;
import java.nio.ByteBuffer;
import java.util.Arrays;
import java.nio.charset.StandardCharsets;

public class SerialCommunication {
    static int BaudRate = 115200;
    static int DataBits = 8;
    static int StopBits = SerialPort.ONE_STOP_BIT;
    static int Parity = SerialPort.NO_PARITY;

    SerialPort serial;

        //SerialPort serial = SerialPort.getCommPort("/dev/ttyUSB0"); // Get port for arduino
    /*
        serial.setComPortParameters(BaudRate, DataBits, StopBits, Parity); // Set parameters for port
        serial.setComPortTimeouts(SerialPort.TIMEOUT_READ_BLOCKING, 1000, 0); // Set timeout for port

        if (serial.openPort()) { // Open port
            System.out.println("Port is opened:)");
        } else {
            System.out.println("Port is not opened:(");
        }*/

       /* while (loop) {
            System.out.print("Enter a command: ");

            Scanner inputStr = new Scanner(System.in);
            String writeMsg = inputStr.nextLine();

            // Write to Arduino
            byte[] writeBuffer = writeMsg.getBytes();
            serial.getOutputStream().write(writeBuffer);
            serial.getOutputStream().flush();
            System.out.println("Message sent: " + writeMsg);
            Thread.sleep(100);

            // Read from Arduino
            byte[] readBuffer = new byte[100];
            int numRead = serial.readBytes(readBuffer, readBuffer.length);
            System.out.print("Read " + numRead + " bytes - ");
            String readMsg = new String(readBuffer);
            System.out.println("Received -> " + readMsg);
            Thread.sleep(100);

            char[] arrReadMsg = readMsg.toCharArray();
            char[] arrWriteMsg = writeMsg.toCharArray();

            writeMsg = new String(writeMsg);
            readMsg = new String(readMsg);

            // Confirmed
            if (arrReadMsg[0] == arrWriteMsg[0] && arrReadMsg[2] == arrWriteMsg[2] &&
                    arrReadMsg[4] == arrWriteMsg[4] && arrReadMsg[6] == arrWriteMsg[6]) {
                serial.getOutputStream().write("CONFIRMED\n".getBytes());
                serial.getOutputStream().flush();
                System.out.println("Message sent: CONFIRMED");
                loop = false;
                Thread.sleep(100);
            }
            // Incorrect
            else {
                serial.getOutputStream().write("INCORRECT\n".getBytes());
                serial.getOutputStream().flush();
                System.out.println("readMsg is: " + readMsg + " writeMsg is: " + writeMsg);
                System.out.println("Message sent: INCORRECT");
                int tempRead = serial.readBytes(readBuffer, readBuffer.length);
                String tempMsg = new String(readBuffer);
                System.out.print("Read " + tempRead + " bytes - ");
                System.out.println("Received -> " + tempMsg);
            }

        }*/
/*

        if (serial.closePort()) {
            System.out.println("Port is closed:)");
        } else {
            System.out.println("Port is not closed:(");
        }
    }
*/


    public void setupSerialCommunication() {
        SerialPort[] q;
        q = SerialPort.getCommPorts();
        //This iterates through the ports and gives a description and the name of the port
        for (SerialPort a : q) {
            System.out.println(a.getDescriptivePortName() + " : " + a.getSystemPortName());
        }

        //Allows user to select which port they want
        /*System.out.println("Which port do you want?");
        Scanner s = new Scanner(System.in);
        int portnumber = s.nextInt();
        s.close();*/

        //SerialPort serial = SerialPort.getCommPort("/dev/tty.usbmodem101");
        //SerialPort serial = SerialPort.getCommPort(s);
        SerialPort serial = SerialPort.getCommPort(q[5].getSystemPortName());
        //SerialPort serial = SerialPort.getCommPort("/dev/ttyUSB0");
        serial.setComPortParameters(BaudRate, DataBits, StopBits, Parity); // Set parameters for port
        serial.setComPortTimeouts(SerialPort.TIMEOUT_READ_BLOCKING, 1000, 0); // Set timeout for port


        this.serial = serial;
        /*if (serial.openPort()) { // Open port
            System.out.println("Port is opened:)");
            this.serial = serial;
        } else {
            System.out.println("Port is not opened:(");
            this.serial = null;
        }*/
    }

    public void sendCommandToArduino(String commandType, String command) throws IOException, InterruptedException {

        if (serial.openPort()) { // Open port
            System.out.println("Port is opened:)");
            this.serial = serial;
        } else {
            System.out.println("Port is not opened:(");
            this.serial = null;
        }

        String readMsg = "";
        boolean loop = false;

        //Send command type
        while (!loop) {
            /*Scanner inputStr = new Scanner(System.in);
            System.out.print("Enter a command: ");
            String writeMsg = inputStr.nextLine();*/
            System.out.println("SendMessage");
            sendMessage(commandType);
            System.out.println("ReceiveMessage");
            readMsg = receiveMessage();
            System.out.println("CompareMessage");
            loop = compareMsg(commandType, readMsg);
        }

        loop = false;

        while(!loop){
            readMsg = receiveMessage();
            loop = compareMsg("Ready", readMsg);
        }

        loop = false;

        //Send data
        while (!loop) {
            Thread.sleep(1000);
            /*Scanner inputStr = new Scanner(System.in);
            System.out.print("Enter a command: ");
            String writeMsg = inputStr.nextLine();*/
            sendMessage(command);
            readMsg = receiveMessage();

            loop = compareMsg(command, readMsg);
        }

        if(commandType.equals("readCard")){
            loop = false;
            while(!loop){
                readMsg = receiveMessage();
                loop = compareMsg("ready", readMsg);
                //Thread.sleep(1000);
            }

            try {
                FileWriter writer = new FileWriter("/Users/jannich/Downloads/OpenCV-Playing-Card-Detector-master/ranksuit.txt");

                writer.write("ready");
                writer.close();

            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        loop = false;
        while(!loop){
            readMsg = receiveMessage();
            loop = compareMsg("DONE", readMsg);
            //Thread.sleep(1000);
        }

        if (serial.closePort()) { // Open port
            System.out.println("Port is closed:)");
        } else {
            System.out.println("Port is still open:(");
        }

        Thread.sleep(100);

            /*char[] arrReadMsg = readMsg.toCharArray();
            char[] arrWriteMsg = commandType.toCharArray();

            for (int i = 0; i < command.length() - 1; i++) {
                if (arrReadMsg[i] == arrWriteMsg[i]) {
                    loop = false;
                }
            }*/




            /*// Write to Arduino
            byte[] writeBuffer = writeMsg.getBytes();
            serial.getOutputStream().write(writeBuffer);
            serial.getOutputStream().flush();
            System.out.println("Message sent: " + writeMsg);
            Thread.sleep(100);*/

            /*// Read from Arduino
            byte[] readBuffer = new byte[10];
            int numRead = serial.readBytes(readBuffer, readBuffer.length);
            System.out.print("Read " + numRead + " bytes - ");
            String readMsg = new String(readBuffer);
            System.out.println("Received -> " + readMsg);
            Thread.sleep(100);*/

            /*writeMsg = new String(writeMsg);
            readMsg = new String(readMsg);

            // Confirmed
            if (arrReadMsg[0] == arrWriteMsg[0] && arrReadMsg[2] == arrWriteMsg[2] &&
                    arrReadMsg[4] == arrWriteMsg[4] && arrReadMsg[6] == arrWriteMsg[6]) {
                serial.getOutputStream().write("CONFIRMED".getBytes());
                serial.getOutputStream().flush();
                System.out.println("Message sent: CONFIRMED");

                while(loop) {

                    Boolean movementDone = true;
                    readBuffer = new byte[10];
                    numRead = serial.readBytes(readBuffer, readBuffer.length);
                    //System.out.print("Read " + numRead + " bytes - ");

                    if(numRead > 0) {
                        readMsg = new String(readBuffer);
                        System.out.println("Received -> " + readMsg);
                        Thread.sleep(100);

                        arrReadMsg = readMsg.toCharArray();
                        String movementStatus = ("DONE");
                        char[] arrMovementStatus = movementStatus.toCharArray();

                        for (int i = 0; i < 4; i++) {
                            if (arrReadMsg[i] != arrMovementStatus[i]) {
                                movementDone = false;
                                break;
                            }
                        }

                        if (movementDone) {
                            System.out.println("Movement is done!");
                            loop = false;
                            break;
                        }
                    }
                }
            }*/
            // Incorrect
            /*else {
                serial.getOutputStream().write("INCORRECT\n".getBytes());
                serial.getOutputStream().flush();
                System.out.println("readMsg is: " + readMsg + " writeMsg is: " + writeMsg);
                System.out.println("Message sent: INCORRECT");
                int tempRead = serial.readBytes(readBuffer, readBuffer.length);
                String tempMsg = new String(readBuffer);
                System.out.print("Read " + tempRead + " bytes - ");
                System.out.println("Received -> " + tempMsg);
            }*/
    }

    private void sendMessage(String writeMsg) throws IOException, InterruptedException {
        // Write to Arduino
        byte[] writeBuffer = writeMsg.getBytes();
        serial.getOutputStream().write(writeBuffer);
        serial.getOutputStream().flush();
        System.out.println("Message sent: " + writeMsg);
        Thread.sleep(100);
    }

    private String receiveMessage() throws IOException, InterruptedException {

        // Read from Arduino
        byte[] readBuffer = new byte[10];
        int numRead = serial.readBytes(readBuffer, readBuffer.length);

        while(numRead < 1) {
            Thread.sleep(100);
            readBuffer = new byte[10];
            numRead = serial.readBytes(readBuffer, readBuffer.length);
        }

            System.out.print("Read " + numRead + " bytes - ");
            String readMsg = new String(readBuffer);
            System.out.println("Received -> " + readMsg);
            Thread.sleep(100);

        return readMsg;
    }

    private Boolean compareMsg(String writeMsg, String readMsg) throws IOException, InterruptedException {

        Boolean match = true;

        char[] arrReadMsg = readMsg.toCharArray();
        char[] arrWriteMsg = writeMsg.toCharArray();

        for (int i = 0; i < writeMsg.length() - 1; i++) {
            if (arrReadMsg[i] != arrWriteMsg[i]) {
                match = false;
                break;
            }
        }

        if(match) {
            System.out.println("Message match! - Sending confirmation");
            sendMessage("CONFIRMED");
            System.out.println("Confirmation sent");
            return true;
        } else {
            System.out.println("Message no match! - Trying again");
            return false;
        }
    }

}
